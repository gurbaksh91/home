﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;



public partial class GenerateEntries : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void InsertButton_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection (@"Data Source=(LocalDb)\v11.0;Initial Catalog=aspnet-OnlineEntries-f711a501-ab2a-46d6-911c-09428b8d0e4e;AttachDbFilename=|DataDirectory|\aspnet-OnlineEntries-f711a501-ab2a-46d6-911c-09428b8d0e4e.mdf;Integrated Security=SSPI");
        con.Open();

     //   SqlCommand insertCommand = new SqlCommand("INSERT INTO FillEntries(Name, Branch, Address, Email, MobileNo, Position) VALUES (@0, @1, @2, @3, @4, @5)", con);
        SqlCommand insertCommand = new SqlCommand("NewInsertCommand", con);
        insertCommand.CommandType = CommandType.StoredProcedure;
        // In the command, there are some parameters denoted by @, you can 
        // change their value on a condition, in my code they're hardcoded.

        insertCommand.Parameters.Add(new SqlParameter("@Name", NameTextBox.Text));
        insertCommand.Parameters.Add(new SqlParameter("@Branch", BranchTextBox.Text));
        insertCommand.Parameters.Add(new SqlParameter("@Address", AddressTextBox.Text));
        insertCommand.Parameters.Add(new SqlParameter("@Email", EmailTextBox.Text));
        insertCommand.Parameters.Add(new SqlParameter("@MobileNo", MobileNoTextBox.Text));
        insertCommand.Parameters.Add(new SqlParameter("@Position", PositionTextBox.Text));

        // Execute the command, and print the values of the columns affected through
        // the command executed.

        insertCommand.ExecuteNonQuery();
        con.Close();
        insertCommand.Dispose();
    }
}