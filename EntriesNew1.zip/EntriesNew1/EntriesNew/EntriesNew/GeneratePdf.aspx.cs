﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Configuration;

namespace EntriesNew
{
    public partial class About : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                fillGrid();
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
        public void fillGrid()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString);
            con.Open();
            string query = "SELECT FillEntries.* FROM FillEntries";
            SqlCommand selectCommand = new SqlCommand(query, con);
            SqlDataAdapter adp = new SqlDataAdapter(selectCommand);
            DataTable tbl = new DataTable();
            adp.Fill(tbl);
            selectCommand.ExecuteNonQuery();
            GridView1.DataSource = tbl;
            GridView1.DataBind();
        }
        protected void btnSerch_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString); con.Open();
            string query = "SELECT FillEntries.* FROM FillEntries where Created_Date between convert(datetime, '" + dt1.Text.ToString() + "' ,101) and convert(datetime,'" + dt2.Text.ToString() + "',101) ";
            SqlCommand selectCommand = new SqlCommand(query, con);
            SqlDataAdapter adp = new SqlDataAdapter(selectCommand);
            DataTable tbl = new DataTable();
            adp.Fill(tbl);
            selectCommand.ExecuteNonQuery();
            GridView1.DataSource = tbl;
            GridView1.DataBind();


        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {


            GridViewRow row = GridView1.SelectedRow;

        }

        public void downloadFile(object sender, EventArgs e, HttpResponse response, string fileRelativePath)
        {
            try
            {
                string contentType = "";
                //Get the physical path to the file.
                string FilePath = HttpContext.Current.Server.MapPath(fileRelativePath);

                string fileExt = Path.GetExtension(fileRelativePath).Split('.')[1].ToLower();

                if (fileExt == "pdf")
                {
                    //Set the appropriate ContentType.
                    contentType = "Application/pdf";
                }

                //Set the appropriate ContentType.
                response.ContentType = contentType;
                response.AppendHeader("content-disposition", "attachment; filename=" + (new FileInfo(fileRelativePath)).Name);

                //Write the file directly to the HTTP content output stream.
                response.WriteFile(FilePath);
                response.End();
            }
            catch
            {
                //To Do
            }
        }

        protected void tnExport_Click(object sender, EventArgs e)
        {
            using (StringWriter sw = new StringWriter())
            {
                using (HtmlTextWriter hw = new HtmlTextWriter(sw))
                {

                    GridView1.RenderControl(hw);
                    StringReader sr = new StringReader(sw.ToString());
                    Document pdfDoc = new Document(PageSize.A2, 10f, 10f, 10f, 0f);
                    HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                    PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
                    pdfDoc.Open();
                    htmlparser.Parse(sr);
                    pdfDoc.Close();

                    Response.ContentType = "application/pdf";
                    Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.pdf");
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.Write(pdfDoc);
                    Response.End();
                }
            }
        }
    }
}