﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Configuration;

namespace EntriesNew
{
    public partial class Contact : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void InsertButton_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString);
            con.Open();

            //   SqlCommand insertCommand = new SqlCommand("INSERT INTO FillEntries(Name, Branch, Address, Email, MobileNo, Position) VALUES (@0, @1, @2, @3, @4, @5)", con);
            SqlCommand insertCommand = new SqlCommand("Sp_fillEntries", con);
            insertCommand.CommandType = CommandType.StoredProcedure;
            // In the command, there are some parameters denoted by @, you can 
            // change their value on a condition, in my code they're hardcoded.

            insertCommand.Parameters.Add(new SqlParameter("@Name", NameTextBox.Text));
            insertCommand.Parameters.Add(new SqlParameter("@Branch", BranchTextBox.Text));
            insertCommand.Parameters.Add(new SqlParameter("@Address", AddressTextBox.Text));
            insertCommand.Parameters.Add(new SqlParameter("@Email", EmailTextBox.Text));
            insertCommand.Parameters.Add(new SqlParameter("@MobileNo", MobileNoTextBox.Text));
            insertCommand.Parameters.Add(new SqlParameter("@Position", PositionTextBox.Text));

            SqlParameter outputIdParam = new SqlParameter("@IsExists", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            insertCommand.Parameters.Add(outputIdParam);
            // Execute the command, and print the values of the columns affected through
            // the command executed.

            insertCommand.ExecuteNonQuery();
            con.Close();
            insertCommand.Dispose();

            int retValue = int.Parse(outputIdParam.Value.ToString());

            if (retValue == 1)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Duplicate entries');", true);

            }
            else
            {

                NameTextBox.Text = "";
                BranchTextBox.Text = "";
                AddressTextBox.Text = "";
                EmailTextBox.Text = "";
                MobileNoTextBox.Text = "";
                PositionTextBox.Text = "";
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Data saved successfully.');", true);
            }
        }
    }
}